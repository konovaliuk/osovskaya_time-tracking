SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
-- SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;



CREATE TABLE public.activities
(
    id          bigint                 NOT NULL,
    name        character varying(255) NOT NULL,
    description text,
    start_time  timestamp without time zone,
    end_time    timestamp without time zone,
    duration    bigint,
    importance  character varying(50),
    status      character varying(50)
);


ALTER TABLE public.activities
    OWNER TO postger;



CREATE SEQUENCE public.activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_id_seq
    OWNER TO postger;



ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;




CREATE TABLE public.activity_requests
(
    id           bigint NOT NULL,
    activity_id  bigint,
    user_id      bigint,
    request_date timestamp without time zone,
    action       character varying(30),
    status       character varying(50)
);


ALTER TABLE public.activity_requests
    OWNER TO postger;



CREATE SEQUENCE public.activity_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_requests_id_seq
    OWNER TO postger;



ALTER SEQUENCE public.activity_requests_id_seq OWNED BY public.activity_requests.id;




CREATE TABLE public.user_authorities
(
    user_id     bigint NOT NULL,
    authorities character varying(50)
);


ALTER TABLE public.user_authorities
    OWNER TO postger;



CREATE TABLE public.users
(
    id         bigint                 NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name  character varying(100) NOT NULL,
    password   character varying(32)  NOT NULL,
    username   character varying(100) NOT NULL
);


ALTER TABLE public.users
    OWNER TO postger;



CREATE TABLE public.users_activities
(
    user_id     bigint NOT NULL,
    activity_id bigint NOT NULL
);


ALTER TABLE public.users_activities
    OWNER TO postger;



CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq
    OWNER TO postger;


ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;



ALTER TABLE ONLY public.activities
    ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);



ALTER TABLE ONLY public.activity_requests
    ALTER COLUMN id SET DEFAULT nextval('public.activity_requests_id_seq'::regclass);



ALTER TABLE ONLY public.users
    ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);



ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);



ALTER TABLE ONLY public.activity_requests
    ADD CONSTRAINT activity_requests_pkey PRIMARY KEY (id);



ALTER TABLE ONLY public.users_activities
    ADD CONSTRAINT users_activities_pk PRIMARY KEY (user_id, activity_id);



ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);




CREATE UNIQUE INDEX users_id_uindex ON public.users USING btree (id);




CREATE UNIQUE INDEX users_username_uindex ON public.users USING btree (username);




ALTER TABLE ONLY public.activity_requests
    ADD CONSTRAINT activity_requests_activities_id_fk FOREIGN KEY (activity_id) REFERENCES public.activities (id) ON DELETE CASCADE;




ALTER TABLE ONLY public.activity_requests
    ADD CONSTRAINT activity_requests_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users (id) ON DELETE CASCADE;


--

ALTER TABLE ONLY public.user_authorities
    ADD CONSTRAINT user_authorities_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users (id) ON UPDATE CASCADE ON DELETE CASCADE;


--

ALTER TABLE ONLY public.users_activities
    ADD CONSTRAINT users_activities_activities_id_fk FOREIGN KEY (activity_id) REFERENCES public.activities (id) ON DELETE CASCADE;




ALTER TABLE ONLY public.users_activities
    ADD CONSTRAINT users_activities_users_id_fk_2 FOREIGN KEY (user_id) REFERENCES public.users (id) ON DELETE CASCADE;

--
-- Insert default admin user
--

INSERT INTO public.users
VALUES (nextval('public.users_id_seq'), 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin');

--
-- Insert admin role to default admin user
--

INSERT INTO public.user_authorities
VALUES ((SELECT id FROM public.users WHERE username = 'admin'), 'ADMIN');
INSERT INTO public.user_authorities
VALUES ((SELECT id FROM public.users WHERE username = 'admin'), 'USER');


--
-- PostgreSQL database dump complete