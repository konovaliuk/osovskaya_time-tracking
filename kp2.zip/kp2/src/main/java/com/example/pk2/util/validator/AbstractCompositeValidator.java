package com.example.pk2.util.validator;

/**
 * Абстрактный класс, который должен быть реализован составным классом валидатора
 *
 * @param <T> Значение, которое необходимо проверить
 */
abstract class AbstractCompositeValidator<T> implements Validator<T> {
    /**
     * Добавление составного валидатора
     *
     * @see Validator
     */
    abstract void addValidator(Validator<T> validator);

    /**
     * Удаление составного валидатора
     * @see Validator
     */
    abstract void removeValidator(Validator<T> validator);
}
