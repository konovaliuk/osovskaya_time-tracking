package com.example.pk2.controller.command;

import javax.servlet.http.HttpServletRequest;

/**
 * Return домашнюю страница для пользователя
 *
 */
public class HomeCommand implements Command {

    HomeCommand() {
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        return "/index.jsp";
    }
}
