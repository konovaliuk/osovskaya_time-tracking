package com.example.pk2.controller.command;

import com.example.pk2.model.service.ActivityService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

/**
 * Команда, которая отвечает на запросы пользователей и дает страницу со всеми действиями, разбитыми на страницы
 * с помощью activity service
 *
 * @see Command
 * @see com.example.pk2.model.entity.Activity
 * @see ActivityService
 */
public class ActivitiesCommand implements Command {
    /**
     * Log4j2 логгер
     */
    private static final Logger log = LogManager.getLogger();
    private final ActivityService activityService;

    ActivitiesCommand(ActivityService activityService) {
        this.activityService = activityService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return name страницы или переотправления
     */
    @Override
    public String execute(HttpServletRequest request) {
        int page = 0;
        int size = 5;
        if (request.getParameter("page") != null) {
            try {
                page = Integer.parseInt(request.getParameter("page"));
            } catch (NumberFormatException e) {
                log.warn("Can not parse number from request parameter");
                return "/WEB-INF/error/404.jsp";
            }
        }
        if (request.getParameter("size") != null) {
            try {
                size = Integer.parseInt(request.getParameter("size"));
            } catch (NumberFormatException e) {
                log.warn("Can not parse number from request parameter");
                return "/WEB-INF/error/404.jsp";
            }
        }
        long numberOfRecords = activityService.getNumberOfRecords();
        long totalPages = (long) Math.ceil((double) numberOfRecords / size);

        request.setAttribute("activities", activityService.getAllActivitiesPageable(page, size));
        request.setAttribute("currentPage", page);
        request.setAttribute("pageSize", size);
        request.setAttribute("totalPages", totalPages);
        return "/WEB-INF/pages/activities.jsp";
    }
}
