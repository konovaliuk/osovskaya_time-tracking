package com.example.pk2.model.dao;

import com.example.pk2.model.entity.Activity;

import java.util.List;

/**
 * Внедрение общего дао для обработки активной сущности в базе данных
 */
public interface ActivityDao extends GenericDao<Activity> {

    /**
     * Поиск постраничных действий в базе данных
     *
     * @param page Страница со списком действий
     * @param size размер страницы списка действий
     * @return выводимый на страницу список действий
     */
    List<Activity> findAllPageable(int page, int size);

    /**
     * @return количество записей об активности
     */
    long getNumberOfRecords();
}
