package com.example.pk2.controller.command;

import javax.servlet.http.HttpServletRequest;

/**
 * Командный интерфейс, предоставляющий метод для возврата имени страницы
 */
public interface Command {
    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return имя страницы или перенаправление на сервлет
     */
    String execute(HttpServletRequest request);
}
