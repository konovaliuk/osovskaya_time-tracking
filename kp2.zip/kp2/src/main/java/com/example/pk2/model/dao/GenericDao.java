package com.example.pk2.model.dao;

import java.util.List;
import java.util.Optional;

/**
 * Интерфейс с операциями CRUD, который реализован со всеми dao
 *
 * @param <T> Субъект, с которым выполняются операции
 */
public interface GenericDao<T> {
    /**
     * @param entity Сущность, которая будет создана
     */
    void create(T entity);

    /**
     * Поиск сущности по айди в базе данных
     *
     * @param id id сущности
     * @return optional сущность
     */
    Optional<T> findById(long id);

    /**
     * Найти все сущности в базе данных
     *
     * @return лист со всеми сущностями
     */
    List<T> findAll();

    /**
     * Обновление сущности в базе данных
     *
     * @param entity Измененная сущность
     */
    void update(T entity);

    /**
     * Удаление сущности из базы данных
     *
     * @param id id сущности, которая будет удалена
     */
    void delete(long id);
}
