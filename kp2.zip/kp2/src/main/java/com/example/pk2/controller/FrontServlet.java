package com.example.pk2.controller;

import com.example.pk2.controller.command.Command;
import com.example.pk2.controller.command.CommandManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Основной сервлет, обрабатывающий все запросы к серверу
 *  и распределяет их по командам
 *
 * @see com.example.pk2.controller.command.Command
 */
public class FrontServlet extends HttpServlet {
    /**
     * Log4j2 logger
     */
    private static final Logger log = LogManager.getLogger();
    /**
     * Command manager позволяет получить нужную комманду
     *
     * @see CommandManager
     */
    private final CommandManager commandManager = CommandManager.getInstance();

    /**
     * Обработка POST-запросов к серверу
     *
     * @param request  HTTP-запрос пользователя на сервер
     * @param response HTTP-ответ от сервера пользователю
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        process(request, response);
    }

    /**
     * Обработка GET-запросов к серверу
     *
     * @param request  HTTP-запрос пользователя на сервер
     * @param response HTTP-ответ от сервера пользователю
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        process(request, response);
    }

    /**
     * Запарсить запрос пользователя и найти подходящую команду для выполнения с помощью command manager
     *
     * @param request  HTTP-запрос пользователя на сервер
     * @param response HTTP-ответ от сервера пользователю
     * @see Command
     * @see CommandManager
     */
    private void process(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getRequestURI().replaceFirst(request.getContextPath() + "/app", "");
        Command command = commandManager.getCommand(path);

        log.info("Current command: " + command.getClass().getSimpleName());

        String page = command.execute(request);

        if (page.contains("redirect")) {
            response.sendRedirect(request.getContextPath() +
                    request.getServletPath() +
                    page.replace("redirect:", ""));
        } else {
            request.getRequestDispatcher(page).forward(request, response);
        }
    }
}
