package com.example.pk2.controller.command;

import com.example.pk2.controller.dto.ActivityDTO;
import com.example.pk2.model.entity.Activity;
import com.example.pk2.model.entity.ActivityImportance;
import com.example.pk2.model.entity.ActivityStatus;
import com.example.pk2.model.service.ActivityService;
import com.example.pk2.util.CommandUtils;
import com.example.pk2.util.validator.CompositeValidator;
import com.example.pk2.util.validator.NotBlankValidator;
import com.example.pk2.util.validator.Result;
import com.example.pk2.util.validator.SizeValidator;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Команда, которая отвечает на запросы пользователей, и добавляет активность в базу данных, используя activity service
 *
 * @see Command
 * @see com.example.pk2.model.entity.Activity
 * @see ActivityService
 */
public class ActivityAddCommand implements Command {
    public static final Logger log = LogManager.getLogger();
    private final ActivityService activityService;
    private ResourceBundle rb;

    ActivityAddCommand(ActivityService activityService) {
        this.activityService = activityService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        rb = ResourceBundle.getBundle("i18n.messages", CommandUtils.getLocaleFromSession(request));
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String importance = request.getParameter("importance");

        if (!ObjectUtils.allNotNull(name, description, importance)) {
            request.setAttribute("importanceLevels", ActivityImportance.values());
            return "/WEB-INF/pages/add-activity.jsp";
        }

        Activity activity = new Activity();
        activity.setName(name);
        activity.setDescription(description);
        activity.setImportance(ActivityImportance.valueOf(importance));
        activity.setStatus(ActivityStatus.PENDING);

        ActivityDTO activityDTO = ActivityDTO.builder()
                .name(name)
                .description(description)
                .importance(ActivityImportance.valueOf(importance))
                .build();

        Map<String, String[]> validationErrorsMap = getValidationErrorsMap(activityDTO);
        if (!validationErrorsMap.isEmpty()) {
            request.setAttribute("activity", activityDTO);
            request.setAttribute("importanceLevels", ActivityImportance.values());
            request.setAttribute("errors", validationErrorsMap);
            return "/WEB-INF/pages/add-activity.jsp";
        }
        activityService.createActivity(activityDTO);
        return "redirect:/activities";
    }

    /**
     * Check activity dto on errors by validator
     *
     * @param activityDTO activity dto filled with user input data
     * @return map with error path in jsp and error messages from validator
     * @see com.example.pk2.util.validator.CompositeValidator
     * @see com.example.pk2.util.validator.Validator
     * @see Result
     */
    private Map<String, String[]> getValidationErrorsMap(ActivityDTO activityDTO) {
        Map<String, String[]> validationErrorMap = new HashMap<>();
        CompositeValidator<String> activityDescriptionValidator = new CompositeValidator<>(
                new SizeValidator(0, 500, rb.getString("validation.activity.description.size"))
        );
        CompositeValidator<String> activityNameValidator = new CompositeValidator<>(
                new SizeValidator(5, 100, rb.getString("validation.activity.name.size")),
                new NotBlankValidator(rb.getString("validation.activity.name.not_blank")));
        Result result = activityNameValidator.validate(activityDTO.getName());
        if (!result.isValid()) {
            validationErrorMap.put("nameErrors", result.getMessage().split("\n"));
        }
        result = activityDescriptionValidator.validate(activityDTO.getDescription());
        if (!result.isValid()) {
            validationErrorMap.put("descriptionErrors", result.getMessage().split("\n"));
        }
        return validationErrorMap;
    }
}
