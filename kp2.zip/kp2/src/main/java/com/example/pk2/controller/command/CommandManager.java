package com.example.pk2.controller.command;

import com.example.pk2.model.service.ActivityRequestService;
import com.example.pk2.model.service.ActivityService;
import com.example.pk2.model.service.UserService;

import java.util.HashMap;
import java.util.Map;

/**
 * Singletone класс, предоставляет пул всех команд и внедряет необходимые службы в их конструктор
 *
 */
public class CommandManager {
    /**
     * Singletone сущность класса
     */
    private static CommandManager commandManager;
    /**
     * Пул комманд
     *
     * @see Command
     */
    private final Map<String, Command> commandMap = new HashMap<>();

    /**
     * Инициализировать пул команд со всеми путями к командам и необходимым службам
     */
    private CommandManager() {
        final UserService userService = new UserService();
        final ActivityService activityService = new ActivityService();
        final ActivityRequestService activityRequestService = new ActivityRequestService();
        commandMap.put("/login", new LoginCommand(userService));
        commandMap.put("/logout", new LogoutCommand());
        commandMap.put("/registration", new RegistrationCommand(userService));
        commandMap.put("/users", new UsersCommand(userService));
        commandMap.put("/index", new HomeCommand());
        commandMap.put("/users/delete", new UserDeleteCommand(userService));
        commandMap.put("/users/update", new UserUpdateCommand(userService));
        commandMap.put("/profile", new UserProfileCommand(userService));
        commandMap.put("/profile/update", new UserProfileUpdateCommand(userService));
        commandMap.put("/activities", new ActivitiesCommand(activityService));
        commandMap.put("/activities/add", new ActivityAddCommand(activityService));
        commandMap.put("/activities/request", new ActivityRequestsCommand(activityRequestService));
        commandMap.put("/activities/delete", new ActivityDeleteCommand(activityService));
        commandMap.put("/activities/mark-time", new MarkTimeCommand(activityService));
        commandMap.put("/activities/request/approve", new ActivityRequestApproveCommand(activityRequestService));
        commandMap.put("/activities/request/reject", new ActivityRequestRejectCommand(activityRequestService));
        commandMap.put("/activities/request/add", new ActivityRequestAddCommand(activityRequestService));
        commandMap.put("/activities/request/complete", new ActivityRequestCompleteCommand(activityRequestService));
    }

    /**
     * @return единственный экземлпяр класса
     */
    public static CommandManager getInstance() {
        if (commandManager == null) {
            synchronized (CommandManager.class) {
                if (commandManager == null) {
                    commandManager = new CommandManager();
                }
            }
        }
        return commandManager;
    }

    /**
     * @param commandName единственный экземпляр класса
     * @return command которая может обрабатывать запрос пользователя с помощью execute метода
     */
    public Command getCommand(String commandName) {
        return commandMap.getOrDefault(commandName, r -> "/index.jsp");
    }
}
