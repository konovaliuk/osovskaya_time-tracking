package com.example.pk2.model.dao;

import com.example.pk2.model.entity.ActivityRequest;

import java.util.List;

/**
 * Реализация общего дао для обработки объекта запроса активности в базе данных
 */
public interface ActivityRequestDao extends GenericDao<ActivityRequest> {
    /**
     * @param activityId id активности в запросе
     * @param userId     id пользователя в запросе
     * @return лист запросов активности с заданными идентификаторами
     */
    List<ActivityRequest> findByActivityIdAndUserId(long activityId, long userId);

    /**
     * Поиск постраничных запросов активности в базе данных
     *
     * @param page страница списка запросов активности
     * @param size размер страницы списка запросов активности
     * @return постраничный лист запросов активности
     */
    List<ActivityRequest> findAllPageable(int page, int size);

    /**
     * @return количество записей запроса активности
     */
    long getNumberOfRecords();
}
