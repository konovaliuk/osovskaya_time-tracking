package com.example.pk2.model.entity;

public enum ActivityImportance {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    EXTREMELY_HIGH("Extremely high");

    private final String simpleName;

    ActivityImportance(String simpleName) {
        this.simpleName = simpleName;
    }

    @Override
    public String toString() {
        return simpleName;
    }
}
