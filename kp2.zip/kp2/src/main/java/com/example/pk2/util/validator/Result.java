package com.example.pk2.util.validator;

/**
 * Компонент результат проверки
 * Интерфейс составного шаблона
 */
public interface Result {
    /**
     * @return если проверенное значение действительно
     */
    boolean isValid();

    /**
     * @return получение сообщения о результате проверки
     */
    String getMessage();
}
