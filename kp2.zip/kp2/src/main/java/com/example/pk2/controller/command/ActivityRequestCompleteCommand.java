package com.example.pk2.controller.command;

import com.example.pk2.model.entity.User;
import com.example.pk2.model.service.ActivityRequestService;
import com.example.pk2.util.CommandUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

/**
 * Добавить запрос активности от пользователя для завершения активности с помощью activity request service
 *
 * @see com.example.pk2.model.entity.Activity
 * @see com.example.pk2.model.entity.ActivityRequest
 * @see ActivityRequestService
 */
public class ActivityRequestCompleteCommand implements Command {
    private static final Logger log = LogManager.getLogger();
    private final ActivityRequestService activityRequestService;

    ActivityRequestCompleteCommand(ActivityRequestService activityRequestService) {
        this.activityRequestService = activityRequestService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        User user = CommandUtils.getUserFromSession(request);

        long activityId;
        try {
            activityId = Long.parseLong(request.getParameter("id"));
        } catch (NumberFormatException e) {
            log.warn("Can not parse number from request parameter");
            return "/WEB-INF/error/404.jsp";
        }

        activityRequestService.makeCompleteActivityRequest(user.getId(), activityId);
        return "redirect:/activities";
    }
}
