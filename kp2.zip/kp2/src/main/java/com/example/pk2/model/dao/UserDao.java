package com.example.pk2.model.dao;

import com.example.pk2.model.entity.User;

import java.util.List;
import java.util.Optional;

/**
 * Реализация общего дао для обработки пользовательского объекта в базе данных
 */
public interface UserDao extends GenericDao<User> {
    /**
     * @param username Имя пользователя
     * @return Объект с заданным именем пользователя
     */
    Optional<User> findByUsername(String username);

    /**
     * Поиск постраничных пользователей в базе данных
     *
     * @param page страница листа пользователей
     * @param size размер страницы листа пользователей
     * @return постраничный список пользователей
     */
    List<User> findAllPageable(int page, int size);

    /**
     * @return список записей User-a
     */
    long getNumberOfRecords();
}
