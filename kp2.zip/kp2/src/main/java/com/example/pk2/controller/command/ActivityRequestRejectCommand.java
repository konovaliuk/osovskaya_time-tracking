package com.example.pk2.controller.command;

import com.example.pk2.model.entity.ActivityRequest;
import com.example.pk2.model.entity.ActivityRequestStatus;
import com.example.pk2.model.service.ActivityRequestService;

import javax.servlet.http.HttpServletRequest;

/**
 * Отклонить запрос активности пользователя
 *
 * @see ActivityRequest
 * @see ActivityRequestService
 */
public class ActivityRequestRejectCommand implements Command {
    private final ActivityRequestService activityRequestService;

    ActivityRequestRejectCommand(ActivityRequestService activityRequestService) {
        this.activityRequestService = activityRequestService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        long activityRequestId = Long.parseLong(request.getParameter("id"));

        ActivityRequest activityRequest = activityRequestService.getActivityRequestById(activityRequestId);

        if (!activityRequest.getStatus().equals(ActivityRequestStatus.PENDING)) {
            return "redirect:/activities/request";
        }

        activityRequestService.rejectActivityRequest(activityRequestId);

        return "redirect:/activities/request";
    }
}
