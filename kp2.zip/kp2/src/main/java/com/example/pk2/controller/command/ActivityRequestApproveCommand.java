package com.example.pk2.controller.command;

import com.example.pk2.model.entity.ActivityRequest;
import com.example.pk2.model.entity.ActivityRequestStatus;
import com.example.pk2.model.service.ActivityRequestService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

/**
 * Одобрить запрос активности пользователя
 *
 * @see ActivityRequest
 * @see ActivityRequestService
 */
public class ActivityRequestApproveCommand implements Command {
    private static final Logger log = LogManager.getLogger();
    private final ActivityRequestService activityRequestService;

    ActivityRequestApproveCommand(ActivityRequestService activityRequestService) {
        this.activityRequestService = activityRequestService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        long activityRequestId;
        try {
            activityRequestId = Long.parseLong(request.getParameter("id"));
        } catch (NumberFormatException e) {
            log.warn("Can not parse number from request parameter");
            return "/WEB-INF/error/404.jsp";
        }

        ActivityRequest activityRequest = activityRequestService
                .getActivityRequestById(activityRequestId);

        if (!activityRequest.getStatus().equals(ActivityRequestStatus.PENDING)) {
            return "redirect:/activities/request";
        }

        switch (activityRequest.getAction()) {
            case ADD:
                activityRequestService.approveAddActivityRequest(activityRequestId);
                break;
            case COMPLETE:
                activityRequestService.approveCompleteActivityRequest(activityRequestId);
                break;
        }

        return "redirect:/activities/request";
    }
}
