package com.example.pk2.model.entity;

public enum Authority {
    USER,
    ADMIN
}
