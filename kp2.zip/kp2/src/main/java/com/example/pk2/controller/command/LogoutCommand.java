package com.example.pk2.controller.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Выходи изз системы
 *
 */
public class LogoutCommand implements Command {

    LogoutCommand() {
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.invalidate();
        request.setAttribute("success", true);
        return "/login.jsp";
    }
}
