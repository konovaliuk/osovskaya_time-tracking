package com.example.pk2.controller.command;

import com.example.pk2.model.entity.User;
import com.example.pk2.model.service.UserService;
import com.example.pk2.util.CommandUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * Получение страницы профиля пользователя с данными о пользователе
 *
 * @see User
 * @see UserService
 */
public class UserProfileCommand implements Command {
    private final UserService userService;

    UserProfileCommand(UserService userService) {
        this.userService = userService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        User user = CommandUtils.getUserFromSession(request);
        request.setAttribute("user", userService.getUserById(user.getId()));
        return "/WEB-INF/pages/profile.jsp";
    }
}
