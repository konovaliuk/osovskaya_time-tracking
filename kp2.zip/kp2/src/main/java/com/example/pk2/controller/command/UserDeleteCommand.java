package com.example.pk2.controller.command;

import com.example.pk2.model.service.UserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

/**
 * Удаление юзера из системы
 *
 * @see com.example.pk2.model.entity.User
 * @see UserService
 */
public class UserDeleteCommand implements Command {
    private static final Logger log = LogManager.getLogger();
    private final UserService userService;

    UserDeleteCommand(UserService userService) {
        this.userService = userService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        long id;
        try {
            id = Long.parseLong(request.getParameter("id"));
        } catch (NumberFormatException e) {
            log.warn("Can not parse number from request parameter");
            return "/WEB-INF/error/404.jsp";
        }
        userService.deleteUserById(id);
        return "redirect:/users";
    }
}
