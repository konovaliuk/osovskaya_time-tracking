package com.example.pk2.model.dao;

import java.sql.Connection;

/**
 * Обертка над классом подключения, позволяющая обрабатывать транзакции
 */
public interface DaoConnection extends AutoCloseable {
    /**
     * Начало транзакции
     */
    void beginTransaction();

    /**
     * Подтверждениетранзакции
     */
    void commit();

    /**
     * Откат транзакции
     */
    void rollback();

    /**
     * Закрытие соеденения
     */
    @Override
    void close();

    /**
     * @return Обертка соеденения
     */
    Connection getConnection();
}
