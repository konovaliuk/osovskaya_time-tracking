package com.example.pk2.util;

import com.example.pk2.model.entity.User;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

/**
 * Класс Util для командных функций
 */
public class CommandUtils {
    /**
     *Получить языковой стандарт, установленный в сеансе, с помощью {@code LocalizationFilter}
     *
     * @param request HTTP-запрос пользователя на сервер
     * @return текущая локаль сеанса
     * @see com.example.pk2.controller.filter.LocalizationFilter
     */
    public static Locale getLocaleFromSession(HttpServletRequest request) {
        String lang = (String) request.getSession().getAttribute("lang");
        return lang != null ? Locale.forLanguageTag(lang) : Locale.getDefault();
    }

    /**
     * Получить пользователя, который установлен в сеансе с помощью {@code AuthFilter}
     *
     * @param request HTTP-запрос пользователя на сервер
     * @return текущий пользователь в сеансе
     * @see com.example.pk2.controller.filter.AuthFilter
     */
    public static User getUserFromSession(HttpServletRequest request) {
        return (User) request.getSession().getAttribute("authUser");
    }
}
