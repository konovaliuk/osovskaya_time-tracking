package com.example.pk2.controller.filter;

import com.example.pk2.model.entity.Authority;
import com.example.pk2.model.entity.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Фильтр аутентификации, выполняющий действие фильтра в <code>doFilter</code> методе
 */
public class AuthFilter implements Filter {
    private static final Logger log = LogManager.getLogger();
    /**
     * Пути, по которым может посещать пользователь с полномочиями ADMIN
     *
     * @see Authority
     */
    private final List<String> adminPaths = Arrays.asList(
            "/",
            "/index",
            "/logout",
            "/profile",
            "/profile/update",
            "/users",
            "/users/delete",
            "/users/update",
            "/activities",
            "/activities/add",
            "/activities/request",
            "/activities/delete",
            "/activities/mark-time",
            "/activities/request/approve",
            "/activities/request/reject",
            "/activities/request/add",
            "/activities/request/complete");
    /**
     * Пути, по которым может посещать пользователь с полномочиями USER
     *
     * @see Authority
     */
    private final List<String> userPaths = Arrays.asList(
            "/",
            "/index",
            "/logout",
            "/profile",
            "/profile/update",
            "/activities",
            "/activities/mark-time",
            "/activities/request/add",
            "/activities/request/complete");
    /**
     * Пути, по которым может посещать пользователь с любымиполномочиями
     */
    private final List<String> defaultPaths = Arrays.asList(
            "/",
            "/index",
            "/login",
            "/registration");
    /**
     * Map с путями, которые требуют аутентификации пользователя
     */
    private final Map<Authority, List<String>> authPaths = new HashMap<>();

    /**
     * Метод инициализации, который инициализирует фильтр и помещает пути в <code>authPaths</code>
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        authPaths.put(Authority.USER, userPaths);
        authPaths.put(Authority.ADMIN, adminPaths);
    }

    /**
     * Метод основного фильтра для выполнения действий фильтра по запросам пользователей.
     * Проверка, разрешено ли пользователю посещать введенный путь
     */
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        HttpSession session = request.getSession();
        String requestURI = request.getRequestURI().replaceFirst(request.getContextPath() + "/app", "");
        log.info("Current request URI: " + requestURI);

        User user = (User) session.getAttribute("authUser");

        if (Objects.isNull(user)) {
            if (defaultPaths.contains(requestURI)) {
                filterChain.doFilter(request, response);
                return;
            } else {
                response.sendRedirect(request.getContextPath() +
                        request.getServletPath() +
                        "/login");
                return;
            }
        }

        List<String> paths = user.getAuthorities()
                .stream()
                .flatMap(authority -> authPaths.get(authority).stream())
                .distinct()
                .collect(Collectors.toList());

        if (paths.contains(requestURI)) {
            filterChain.doFilter(request, response);
        } else {
            response.setStatus(403);
            request.getRequestDispatcher("/WEB-INF/error/403.jsp").forward(request, response);
        }
    }

    @Override
    public void destroy() {

    }
}
