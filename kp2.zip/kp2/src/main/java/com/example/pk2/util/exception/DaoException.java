package com.example.pk2.util.exception;

/**
 * Исключение времени выполнения, выброшенное на уровне dao для завершения SQLException
 *
 * @see java.sql.SQLException
 */
public class DaoException extends RuntimeException {
    public DaoException() {
        super();
    }

    public DaoException(String message) {
        super(message);
    }

    public DaoException(String message, Throwable cause) {
        super(message, cause);
    }

    public DaoException(Throwable cause) {
        super(cause);
    }
}
