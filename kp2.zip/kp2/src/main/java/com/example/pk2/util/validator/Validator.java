package com.example.pk2.util.validator;

/**
 * Компонентный интерфейс составного шаблона
 *
 * @param <T> Значение, которое необходимо проверить
 */
public interface Validator<T> {
    /**
     * @param value Значение, которое необходимо подтвердить
     * @return результат проверки
     */
    Result validate(T value);
}
