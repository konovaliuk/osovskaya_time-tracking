package com.example.pk2.controller.command;

import com.example.pk2.model.service.ActivityService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

/**
 * Команда, которая отвечает на запросы пользователя и удаляет активность из базы данных, используя
 *
 * @see Command
 * @see com.example.pk2.model.entity.Activity
 * @see ActivityService
 */
public class ActivityDeleteCommand implements Command {
    private static final Logger log = LogManager.getLogger();
    private final ActivityService activityService;

    ActivityDeleteCommand(ActivityService activityService) {
        this.activityService = activityService;
    }

    /**
     * @param request HTTP-запрос пользователя на сервер
     * @return название страницы или перенаправление
     */
    @Override
    public String execute(HttpServletRequest request) {
        long activityId;
        try {
            activityId = Long.parseLong(request.getParameter("id"));
        } catch (NumberFormatException e) {
            log.warn("Can not parse number from request parameter");
            return "/WEB-INF/error/404.jsp";
        }
        activityService.deleteActivity(activityId);
        return "redirect:/activities";
    }
}
