package com.kp4.kp_4.model.entity;

/**
 * Статусы запроса активности
 *
 * @see ActivityRequest
 */
public enum ActivityRequestStatus {
    PENDING("Pending"),
    APPROVED("Approved"),
    REJECTED("Rejected");

    private final String simpleName;

    ActivityRequestStatus(String simpleName) {
        this.simpleName = simpleName;
    }

    @Override
    public String toString() {
        return simpleName;
    }
}
