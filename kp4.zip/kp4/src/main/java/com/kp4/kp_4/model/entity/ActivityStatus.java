package com.kp4.kp_4.model.entity;

/**
 * Статусы активности
 *
 * @see Activity
 */
public enum ActivityStatus {
    PENDING("Pending"),
    ACTIVE("Active"),
    COMPLETED("Completed");

    private final String simpleName;

    ActivityStatus(String simpleName) {
        this.simpleName = simpleName;
    }

    @Override
    public String toString() {
        return simpleName;
    }
}
