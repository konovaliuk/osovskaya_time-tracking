package com.kp4.kp_4.model.repository;

import com.kp4.kp_4.model.entity.Activity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Репозиторий JPA, обеспечивающий доступ к сопоставлению объектов действий в базе данных.
 */
@Repository
public interface ActivityRepository extends JpaRepository<Activity, Long> {
}
