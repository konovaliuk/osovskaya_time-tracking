package com.kp4.kp_4.model.entity;

/**
 *
 * Уровни важности для объекта действия
 *
 * @see Activity
 */
public enum ActivityImportance {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    EXTREMELY_HIGH("Extremely high");

    private final String simpleName;

    ActivityImportance(String simpleName) {
        this.simpleName = simpleName;
    }

    @Override
    public String toString() {
        return simpleName;
    }
}
