package com.kp4.kp_4.model.entity;

import org.springframework.security.core.GrantedAuthority;

/**
 * Полномочия пользователя
 *
 * @see User
 */
public enum Authority implements GrantedAuthority {
    USER,
    ADMIN;

    @Override
    public String getAuthority() {
        return name();
    }
}
