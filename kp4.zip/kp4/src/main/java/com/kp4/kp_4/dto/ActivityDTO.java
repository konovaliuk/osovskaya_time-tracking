package com.kp4.kp_4.dto;

import com.kp4.kp_4.model.entity.ActivityImportance;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Объект передачи данных для перемещения данных о деятельности от контроллера к сервису
 *
 * @see com.kp4.kp_4.model.entity.Activity
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ActivityDTO {
    @NotBlank(message = "{validation.activity.name.not_blank}")
    @Size(min = 5, max = 100, message = "{validation.activity.name.size}")
    private String name;
    @Size(max = 500, message = "{validation.activity.description.size}")
    private String description;
    @NotNull(message = "{validation.activity.importance.not_null}")
    private ActivityImportance importance;
}
