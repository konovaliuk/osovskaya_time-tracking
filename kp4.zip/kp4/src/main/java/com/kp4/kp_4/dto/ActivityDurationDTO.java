package com.kp4.kp_4.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

/**
 * Объект передачи данных для передачи данных о продолжительности активности от контроллера к сервису
 *
 * @author Yurii Matora
 * @see com.kp4.kp_4.model.entity.Activity
 */
@Data
public class ActivityDurationDTO {
    @PositiveOrZero(message = "{validation.activity.duration.days.positive_or_zero}")
    @NotNull(message = "{validation.activity.duration.days.not_null}")
    private Integer days;

    @PositiveOrZero(message = "{validation.activity.duration.hours.positive_or_zero}")
    @NotNull(message = "{validation.activity.duration.hours.not_null}")
    private Integer hours;

    @PositiveOrZero(message = "{validation.activity.duration.minutes.positive_or_zero}")
    @NotNull(message = "{validation.activity.duration.minutes.not_null}")
    private Integer minutes;
}
