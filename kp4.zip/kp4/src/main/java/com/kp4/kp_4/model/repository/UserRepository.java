package com.kp4.kp_4.model.repository;

import com.kp4.kp_4.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Репозиторий JPA, предоставляющий доступ к отображению объектов пользователя в базе данных.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
