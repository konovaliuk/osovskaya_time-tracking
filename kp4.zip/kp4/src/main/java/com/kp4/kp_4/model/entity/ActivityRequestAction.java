package com.kp4.kp_4.model.entity;

/**
 * Действия для запроса активности
 *
 * @see ActivityRequest
 */
public enum ActivityRequestAction {
    ADD("Add"),
    COMPLETE("Complete");

    private final String simpleName;

    ActivityRequestAction(String simpleName) {
        this.simpleName = simpleName;
    }

    @Override
    public String toString() {
        return simpleName;
    }
}
