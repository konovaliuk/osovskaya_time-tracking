package com.kp4.kp_4.model.repository;

import com.kp4.kp_4.model.entity.ActivityRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Репозиторий JPA, предоставляющий доступ к отображению сущности запроса активности в базе данных.
 */
@Repository
public interface ActivityRequestRepository extends JpaRepository<ActivityRequest, Long> {
    List<ActivityRequest> findByActivityIdAndUserId(Long activityId, Long userId);
}
